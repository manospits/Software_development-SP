#ifndef _UTILS_H_
#define _UTILS_H_

#include <stdint.h>

uint32_t min(uint32_t, uint32_t);

#endif // _UTILS_H_
